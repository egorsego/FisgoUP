package ch.ethz.ssh2.transport;

/**
 * NegotiateException.
 * 
 * @author Christian Plattner, plattner@inf.ethz.ch
 * @version $Id: NegotiateException.java,v 1.1 2005/05/26 14:53:29 cplattne Exp $
 */
public class NegotiateException extends Exception
{
	private static final long serialVersionUID = 3689910669428143157L;
}
